<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style type="text/css">
.footer1{
	
	border: 1px solid black; 
}
.footer2{
	
	border: 1px solid black; 
	height:82px;
}

</style>
<div class="footer">
	<div class="col-md-4 footer1">	
		<p>Designed & Developed By:</p>
		<p>Vaibhav Gangrade</p>	
		<span>Mail:</span>
		<span>vivgangs@gmail.com</span>
	</div>
	<div class="col-md-4 footer2">	
		<center><p>Follow Me:</p>
		<span><i class="fa fa-facebook-square" style="font-size:48px;color:blue"></i></span>&nbsp;&nbsp;
		<span><i class="fa fa-linkedin-square" style="font-size:48px;color:blue"></i></span>&nbsp;&nbsp;
		<span><i class="fa fa-youtube" style="font-size:48px;color:blue"></i></span>
		<span><i class="fa fa-youtube" style="font-size:48px;color:blue"></i></span>
	</center>
	</div>
	<div class="col-md-4 footer1">	
		<p>Address:</p>
		<p>Vaibhav Gangrade</p>	
	</div>
	<div class="col-md-12">
		<span>Copyrights &copy;</span>
	</div>
</div>